#!/bin/bash
cd "$(dirname "$0")"
sudo rm -rf "/Applications/VideoBar.app"
sudo ditto --norsrc --noextattr --noacl "VideoBar.app" "/Applications/VideoBar.app"
sudo chown -R root:wheel "/Applications/VideoBar.app"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "/Applications/VideoBar.app"
open "/Applications/VideoBar.app"
echo "已安装 VideoBar 1.4.0 到 /Applications"
