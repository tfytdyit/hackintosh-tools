#!/bin/bash
# 双击（或右键→打开）本脚本，把 VideoBar 装进 /Applications
cd "$(dirname "$0")" || exit 1
echo "== 安装 VideoBar 到 /Applications（需要一次管理员密码）"
sudo rm -rf /Applications/VideoBar.app
sudo ditto "$(pwd)/VideoBar.app" /Applications/VideoBar.app || exit 1
sudo chown -R root:wheel /Applications/VideoBar.app
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f /Applications/VideoBar.app >/dev/null 2>&1
pkill -f "VideoBar.app/Contents/MacOS/VideoBar" 2>/dev/null
open /Applications/VideoBar.app
echo "装好了，可以关掉这个窗口。"
