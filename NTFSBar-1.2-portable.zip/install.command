#!/bin/bash
cd "$(dirname "$0")"
sudo rm -rf /Applications/NTFSBar.app
sudo ditto "$PWD/NTFSBar.app" /Applications/NTFSBar.app
sudo chown -R root:wheel /Applications/NTFSBar.app
sudo /System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f /Applications/NTFSBar.app
open /Applications/NTFSBar.app
echo "已安装 NTFSBar 到 /Applications"
