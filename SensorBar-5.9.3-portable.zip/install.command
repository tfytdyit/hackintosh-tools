#!/bin/bash
cd "$(dirname "$0")"
sudo rm -rf "/Applications/SensorBar.app"
sudo ditto --norsrc --noextattr --noacl "SensorBar.app" "/Applications/SensorBar.app"
sudo chown -R root:wheel "/Applications/SensorBar.app"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "/Applications/SensorBar.app"
open "/Applications/SensorBar.app"
echo "已安装 SensorBar 5.9.3 到 /Applications"
