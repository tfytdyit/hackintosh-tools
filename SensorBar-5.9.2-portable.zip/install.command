#!/bin/bash
# 双击（或右键→打开）本脚本，把 SensorBar 装进 /Applications
cd "$(dirname "$0")" || exit 1
echo "== 安装 SensorBar 到 /Applications（需要一次管理员密码）"
sudo rm -rf /Applications/SensorBar.app
sudo ditto "$(pwd)/SensorBar.app" /Applications/SensorBar.app || exit 1
sudo chown -R root:wheel /Applications/SensorBar.app
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f /Applications/SensorBar.app >/dev/null 2>&1
pkill -f "SensorBar.app/Contents/MacOS/SensorBar" 2>/dev/null
open /Applications/SensorBar.app
echo "装好了，可以关掉这个窗口。"
